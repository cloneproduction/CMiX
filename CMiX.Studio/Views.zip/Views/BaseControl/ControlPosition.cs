﻿// Copyright (c) CloneProduction Shanghai Company Limited (https://cloneproduction.net/)
// Distributed under the MIT license. See the LICENSE.md file in the project root for more information.

namespace CMiX.Studio.Views.BaseControl
{
    public enum ControlPosition
    {
        Top,
        Middle,
        Bottom,
        Left,
        Right,
        All,
        None,
    };
}
