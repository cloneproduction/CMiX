﻿using System.Windows.Controls;

namespace CMiX.Studio.Views
{
    public partial class EntitySelectionPanel : UserControl
    {
        public EntitySelectionPanel()
        {
            InitializeComponent();
        }
    }
}
