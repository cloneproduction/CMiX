﻿using System.Windows.Controls;

namespace CMiX.Studio.Views
{
    public partial class CompositionSettings : UserControl
    {
        public CompositionSettings()
        {
            InitializeComponent();
        }
    }
}
