﻿using System.Windows.Controls;

namespace CMiX.Studio.Views
{
    public partial class AmbientOcclusion : UserControl
    {
        public AmbientOcclusion()
        {
            InitializeComponent();
        }
    }
}
